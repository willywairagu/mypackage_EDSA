## mypackage

This library w+as created as an example of how to create a python package 
under the Data Engineering accelerator course by Explore Data Science Academy.

